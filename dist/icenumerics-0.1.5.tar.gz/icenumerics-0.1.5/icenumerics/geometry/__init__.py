from icenumerics.geometry.square import *
from icenumerics.geometry.honeycomb import *